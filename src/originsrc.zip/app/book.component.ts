import {Component, ViewEncapsulation} from '@angular/core';
declare var document:any;
@Component({
    selector:'my-book',
    templateUrl: './app/book.component.html',
    styleUrls:['./app/book.component.css'],
    encapsulation:ViewEncapsulation.Native
})

export class BookComponent {
    name = "안드로이드 게임 프로그래밍";
    ngOnInit(){
        var el = document.getElementsByClassName('font-orange')[0];
        console.log(el)
    }
    setName(name:any){
        this.name = name;
    }
    getName(){
        return this.name;
    }
}

